package coupon_project.beans;

public enum Category {
    FOOD,
    ELECTRICITY,
    RESTAURANT,
    VACATION
}
