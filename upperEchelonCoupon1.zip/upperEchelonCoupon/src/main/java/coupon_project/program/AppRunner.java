package coupon_project.program;

import coupon_project.coupons_exterminator.DailyJob;
import coupon_project.db_util.DataBaseManager;
import coupon_project.tester.Test;
import coupon_project.tester.TestAdminFacade;

public class AppRunner {
    public static void main(String[] args) {

        Test.testAll();
    }
}
